import copy
from random import randint
from BoardClasses import Move
from BoardClasses import Board
#The following part should be completed by students.
#Students can modify anything except the class name and exisiting functions and varibles.
class StudentAI():

    def __init__(self,col,row,p):
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col,row,p)
        self.board.initialize_game()
        self.color = ''
        self.opponent = {1:2,2:1}
        self.color = 2
    def get_move(self,move):
        if len(move) != 0:
            self.board.make_move(move,self.opponent[self.color])
        else:
            self.color = 1
        # moves = self.board.get_all_possible_moves(self.color)
        # index = randint(0,len(moves)-1)
        # inner_index =  randint(0,len(moves[index])-1)
        # move = moves[index][inner_index]
        all_moves = self.board.get_all_possible_moves(self.color)
        best_move = all_moves[0][0]

        move = self.miniMax(self.board, self.color, 3)[1]
        if move == None: #if min max returns a bad value pick random
            move = best_move
        self.board.make_move(move,self.color)
        return move



    def miniMax(self, position, current_player, depth):
        if depth == 0:
            return self.curr_board_score(current_player), None  # Return None for best_move at the leaf nodes

        best_move = None  # Initialize best_move to None
        temp_board = copy.deepcopy(position) #makes a temporary board to test recursive changes

        #MAX
        if current_player == self.color:
            maxEval = -float('inf') 
            for moves in temp_board.get_all_possible_moves(current_player): #goes through move objects
                for move in moves:
                    temp_board.make_move(move, current_player)
                    evaluation, _ = self.miniMax(temp_board, self.opponent[self.color], depth - 1)
                    temp_board.undo()  # Undo the move for backtracking
                    if maxEval < evaluation:
                        maxEval = evaluation
                        best_move = move

            return maxEval, best_move

        #MIN
        elif current_player == self.opponent[self.color]:
            minEval = float('inf')
            for moves in temp_board.get_all_possible_moves(current_player):
                for move in moves:
                    temp_board.make_move(move, current_player)
                    evaluation, _ = self.miniMax(temp_board, self.color, depth - 1)
                    temp_board.undo()  # Undo the move for backtracking
                    if minEval > evaluation:
                        minEval = evaluation
                        best_move = move

            return minEval, best_move







    def curr_board_score(self, curr_player):
        #WEIGHT CHART 
        #KING = 0.5
        #NORMAL = 1
        #CENTER ROW = 0.25
        #KING PROMOTION = 0.1
        white_kings = 0
        black_kings = 0

        centerRow1 = self.row // 2 #gets the middle 2 rows
        centerRow2 = centerRow1 - 1

        white_center = 0
        black_center = 0

        white_promotion = 0
        black_promotion = 0
        # Evaluate based on the number of kings
        for c in range(self.col):
            for r in range(self.row):
                current_piece = self.board.board[c][r]

                if current_piece is not None:
                    if current_piece.get_color() == self.color:
                        if (r == 1): #if white is about to be promoted
                            white_center += 1
                        if (r == centerRow1 or r == centerRow2): #if the piece is in the center row
                            white_center += 1
                        if current_piece.is_king: #if the pices is a king
                            white_kings += 1
                    elif current_piece.get_color() == self.opponent[self.color]:
                        if (r == 1): #if white is about to be promoted
                            black_center += 1
                        if (r == centerRow1 or r == centerRow2):
                            black_center += 1
                        if current_piece.is_king:
                            black_kings += 1

        if curr_player == self.color: #calculates the score using amt of colors and kings 
            return self.board.black_count - self.board.white_count + (white_kings * 0.5 - black_kings * 0.5) + (white_center * 0.25 - black_center * 0.25) + (white_promotion * 0.1 - black_promotion * 0.1)
        else:
            return self.board.white_count - self.board.black_count + (black_kings * 0.5 - white_kings * 0.5)+ (black_center * 0.25 - white_center * 0.25) + (black_promotion * 0.1 - white_promotion * 0.1)
        

